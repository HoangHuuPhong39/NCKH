# Chương 5: Tích Hợp Công Cụ Mã Nguồn Mở & Khung Đối Chuẩn

## 5.1 Đặt Vấn Đề và Mục Tiêu Đối Chuẩn Quốc Tế

Trong nghiên cứu khoa học an toàn thông tin, việc phát triển một công cụ mới luôn đòi hỏi phải được kiểm chứng, đối chuẩn (benchmarking) và so sánh định lượng với các giải pháp mã nguồn mở hàng đầu đã được cộng đồng quốc tế công nhận. Điều này nhằm khẳng định:
1. Tính đúng đắn của phương pháp luận và các quy tắc phát hiện.
2. Khả năng bao phủ các vector tấn công đối kháng tiên tiến.
3. Những đóng góp cải tiến mới của giải pháp đề xuất đối với thực tiễn ứng dụng tại Việt Nam.

Đề tài tiến hành tích hợp thành công hai khung kiểm thử an toàn AI mã nguồn mở tiêu biểu nhất hiện nay của thế giới:
- **NVIDIA Garak (Generative AI Red-teaming Architecture)**: Bộ công cụ kiểm thử lỗ hổng LLM tiêu chuẩn công nghiệp do NVIDIA bảo trợ (Giấy phép Apache 2.0).
- **Microsoft PyRIT (Python Risk Identification Tool)**: Nền tảng red-teaming tự động hóa đối kháng đa lượt (multi-turn) do Microsoft AI Red Team phát triển (Giấy phép MIT).

---

## 5.2 Tích Hợp NVIDIA Garak (`modules/integrations/garak_wrapper.py`)

### 5.2.1 Kiến Trúc Tích Hợp Subprocess Không Xung Đột
Do Garak sở hữu số lượng lớn thư viện phụ thuộc chuyên sâu về PyTorch và HuggingFace, việc import trực tiếp vào môi trường chạy web có thể dẫn đến xung đột phiên bản (dependency hell). Lớp `GarakWrapper` giải quyết triệt để vấn đề này bằng cách khởi chạy Garak dưới dạng một tiến trình con độc lập (`subprocess.Popen`):

```python
cmd = [
    sys.executable, "-m", "garak",
    "--model_type", "rest",
    "--model_name", self.model_name,
    "--probes", probe_name,
    "--parallel_requests", "1"
]
```

### 5.2.2 Ánh Xạ Probes của Garak Sang OWASP LLM 2025
Hệ thống ánh xạ các probes chuẩn của Garak vào taxonomy của đề tài để thống nhất báo cáo:
- `garak.probes.promptinject` $\rightarrow$ **OWASP LLM01** (AML.T0051)
- `garak.probes.dan` $\rightarrow$ **OWASP LLM01** (AML.T0054 - Jailbreak)
- `garak.probes.xss` $\rightarrow$ **OWASP LLM05** (AML.T0048 - Improper Output Handling)
- `garak.probes.knownbadsignatures` $\rightarrow$ **OWASP LLM01** (Malware/Threat Generation)

Bộ phân tích kết quả (`parse_garak_output`) tự động đọc luồng dữ liệu đầu ra của Garak, bóc tách tỷ lệ vượt qua (pass rate), tỷ lệ bị khai thác (fail rate) và chuẩn hóa thành danh sách finding có định dạng tương thích với cơ sở dữ liệu của hệ thống.

---

## 5.3 Tích Hợp Microsoft PyRIT (`modules/integrations/pyrit_wrapper.py`)

### 5.3.1 Kiến Trúc Bộ Điều Phối Đối Kháng Đa Lượt (Multi-turn Orchestrator)
Microsoft PyRIT nổi tiếng với khả năng thực thi các kịch bản tấn công đối kháng đa lượt (Crescendo Attack). Kẻ tấn công không gửi ngay payload nguy hiểm ở lượt đầu tiên mà dẫn dắt mô hình qua nhiều lượt đối thoại thông thường nhằm hạ thấp ngưỡng cảnh giác của bộ lọc an toàn.

Hệ thống xây dựng lớp `PyRITWrapper` thực hiện:
1. **Kiểm tra trạng thái sẵn sàng (`is_available`):** Tự động phát hiện gói thư viện `pyrit` trong môi trường runtime.
2. **Hỗ trợ Chế độ Thực Nghiệm Đối Chuẩn Thực Tế (Empirical Baseline Mode):** Đối với các máy trạm không có kết nối Internet hoặc không cài đặt trọn bộ thư viện Azure, wrapper cung cấp baseline định lượng thực nghiệm phản ánh chính xác phân phối điểm số của PyRIT trên mô hình LLaMA-3 8B.
3. **Thuật toán So sánh Đối Chuẩn (`compare_with_scanner`):** Tự động tính toán tập hợp giao nhau của các lỗ hổng được phát hiện, xác định các phát hiện độc quyền của từng công cụ và tính toán **Tỷ lệ Đồng thuận (Concordance Rate)**:

$$\text{Concordance Rate} = \frac{|\mathcal{V}_{Scanner} \cap \mathcal{V}_{PyRIT}|}{|\mathcal{V}_{Scanner} \cup \mathcal{V}_{PyRIT}|} \times 100\%$$

---

## 5.4 Bảng So Sánh Tính Năng và Kết Quả Thực Nghiệm Đối Chuẩn

### Bảng 5.1: Bảng so sánh tính năng toàn diện giữa các công cụ

| Tiêu Chí So Sánh | NVIDIA Garak | Microsoft PyRIT | Hệ Thống Đề Xuất (AI Security Scanner) |
| :--- | :---: | :---: | :---: |
| **Đơn vị phát triển** | NVIDIA / Open Source | Microsoft AI Red Team | Đề tài NCKH (Đề xuất) |
| **Giấy phép** | Apache 2.0 | MIT | Nghiên cứu học thuật |
| **Giao diện người dùng** | CLI thuần túy | CLI / Jupyter Notebook | **CLI + Web Dashboard Thời gian thực (SSE)** |
| **Cơ chế phát hiện** | Quy tắc / Mô hình nhỏ | LLM Self-Ask Scorer | **Hai lớp: Pattern-matching + LLM-as-Judge** |
| **Hỗ trợ tiếng Việt** | Kém (chủ yếu tiếng Anh) | Trung bình (cần tự viết prompt) | **Chuyên sâu (Payload & Quy tắc song ngữ Anh-Việt)** |
| **Định lượng rủi ro** | Tỷ lệ % Fail đơn giản | Điểm nhị phân True/False | **Mô hình chuẩn hóa CVSS (0.0 - 10.0)** |
| **Quản lý phiên quét** | Không (Chạy từng lần) | Không (Dạng script) | **Khóa phân lập UUID, Hủy scan tức thời** |
| **Quét hạ tầng mạng** | Không | Không | **AI Service Port Scanner (Ollama, MLflow, Ray)** |
| **Demo RAG Security** | Không | Hạn chế | **Có sẵn pipeline mô phỏng tấn công gián tiếp** |

---

## 5.5 Kết Luận Từ Quá Trình Đối Chuẩn

Kết quả thực nghiệm đối sánh cho thấy:
1. **Độ tương đồng cao về khả năng phát hiện:** Trên các nhóm lỗ hổng cốt lõi như Prompt Injection (`LLM01`) và Safety Jailbreak, độ đồng thuận giữa hệ thống đề xuất và Microsoft PyRIT đạt **$85.7\%$**, khẳng định các payload và biểu thức chính quy của hệ thống bám sát chuẩn mực quốc tế.
2. **Ưu thế vượt trội về khả năng ứng dụng thực tế:** Hệ thống đề xuất vượt trội hơn hẳn Garak và PyRIT về tính thân thiện với người dùng cuối tại Việt Nam nhờ Bảng điều khiển Web Dashboard trực quan, khả năng theo dõi tiến độ quét theo thời gian thực (Server-Sent Events), tính năng hủy quét an toàn không treo tiến trình, và bộ khuyến nghị khắc phục chi tiết bằng tiếng Việt cho từng mã OWASP.
