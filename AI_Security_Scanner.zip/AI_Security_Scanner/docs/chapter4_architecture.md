# Chương 4: Thiết Kế Kiến Trúc Hệ Thống & Cơ Chế Thực Thi

## 4.1 Tổng Quan Kiến Trúc Đa Tầng (Architectural Overview)

Hệ thống **AI Security Scanner** được thiết kế theo mô hình kiến trúc module hóa phân tầng (Modular Layered Architecture), đảm bảo tính tách biệt trách nhiệm (Separation of Concerns), khả năng mở rộng thêm các kỹ thuật tấn công mới, và tính tương thích cao với cả giao diện dòng lệnh (CLI) lẫn bảng điều khiển web tương tác trực quan (Interactive Web Dashboard).

```mermaid
graph TD
    subgraph UI ["Tầng Giao Diện Người Dùng (Presentation Layer)"]
        CLI["CLI Interface (Rich Console)"]
        WEB["Web Dashboard (HTML5 + CSS + JavaScript)"]
    end

    subgraph Service ["Tầng Dịch Vụ & Điều Phối (Service & API Layer)"]
        FLASK["Flask REST Controller & SSE Streamer"]
        DISPATCHER["Task Dispatcher & Concurrency Manager"]
    end

    subgraph Core ["Tầng Lõi Nghiệp Vụ (Core Engine)"]
        LLM_CLIENT["SimpleLLMClient (Ollama / OpenAI REST)"]
        RISK_ENGINE["CVSS-like RiskScorer"]
        OWASP_MAP["OWASP & MITRE Mapper"]
        REPORT_GEN["Report Generator (HTML / JSON / MD)"]
    end

    subgraph Modules ["Tầng Module Tấn Công & Phát Hiện (Modules Layer)"]
        EXPLOITS["8 Exploit Modules (LLM01 - LLM10)"]
        PORT_SCAN["AI Port Scanner (AML.T0008)"]
        DETECTORS["Two-tier Detectors (PatternDetector + LLMJudge)"]
        INTEGRATIONS["Open-Source Wrappers (NVIDIA Garak + MS PyRIT)"]
    end

    subgraph Storage ["Tầng Lưu Trữ Dữ Liệu (Persistence Layer)"]
        SQLITE[("SQLite Database (scanner.db)")]
        TAXONOMY_JSON["Taxonomy Metadata (taxonomy.json)"]
        BENCHMARK_DATA["Benchmark Dataset (benchmark_dataset.json)"]
    end

    UI --> Service
    Service --> Core
    Core --> Modules
    Core --> Storage
    Modules --> Storage
```

---

## 4.2 Cơ Chế Phân Lập Luồng Quét & Xử Lý Đồng Thời (Concurrency Isolation)

Trong các phiên bản ban đầu của các hệ thống red-teaming, việc người dùng vô tình bấm nút quét nhiều lần hoặc thay đổi cấu hình giữa chừng có thể gây ra hiện tượng cạnh tranh tài nguyên (Race Condition), xung đột tiến trình gửi gói tin đến Ollama và làm xáo trộn luồng truyền phát sự kiện.

Để giải quyết triệt để vấn đề này, kiến trúc hệ thống áp dụng cơ chế **Phân Lập Quét Đơn Nhất với Thẻ Định Danh UUID**:

```python
# Khóa bảo vệ toàn cục và Thẻ định danh phiên quét đang hoạt động
scan_lock = threading.Lock()
active_scan_token: Optional[str] = None
```

### 4.2.1 Quy trình Khởi tạo và Khóa Phiên
1. Khi có yêu cầu quét mới (`POST /api/scan`), hệ thống yêu cầu khóa `scan_lock.acquire(blocking=False)`. Nếu phiên trước đó đang chạy, yêu cầu mới bị từ chối ngay lập tức với mã lỗi HTTP 409 Conflict.
2. Một mã định danh duy nhất ngẫu nhiên (UUIDv4) được gán làm `active_scan_token`.
3. Luồng làm việc chạy nền (`threading.Thread(target=scan_worker)`) được khởi chạy, mang theo bản sao của `scan_token`.

### 4.2.2 Cơ Chế Hủy Quét Tức Thời (Instant Scan Abort)
Tại từng bước trong vòng lặp duyệt qua các payload, hàm kiểm tra ngắt `is_aborted()` được kích hoạt:

```python
def is_aborted() -> bool:
    return (
        scan_status.get("status") == "aborting"
        or current_scan_token != active_scan_token
    )
```

Khi người dùng nhấn nút **"⏹️ Hủy Scan"** trên giao diện:
- Cờ trạng thái lập tức chuyển sang `aborting`.
- `active_scan_token` được đặt về `None`.
- Luồng quét nền lập tức nhận diện tín hiệu hủy tại payload kế tiếp, ngừng gửi request tới LLM, giải phóng khóa `scan_lock`, và bắn sự kiện SSE thông báo dừng quét thành công.

---

## 4.3 Truyền Phát Sự Kiện Thời Gian Thực (Server-Sent Events - SSE Streaming)

Nhằm đảm bảo trải nghiệm người dùng tương đương các công cụ bảo mật thương mại chuyên nghiệp, hệ thống không sử dụng cơ chế kéo dữ liệu định kỳ (polling) gây lãng phí tài nguyên mạng, mà triển khai giao thức truyền phát một chiều thời gian thực **Server-Sent Events (SSE)** thông qua endpoint `/api/scan/stream`.

### 4.3.1 Cấu Trúc Hàng Đợi và Bộ Phát Sự Kiện
Mỗi tiến trình quét sở hữu một hàng đợi sự kiện thread-safe `queue.Queue`. Hàm `emit(event_type, data)` đưa thông điệp vào hàng đợi và được bộ lặp SSE chuyển đổi thành các frame chuẩn HTTP `text/event-stream`:

```text
event: progress
data: {"current": 4, "total": 12, "percent": 33, "module": "prompt_injection"}

event: finding
data: {"payload": "...", "response": "...", "is_vuln": true, "severity": "HIGH", "risk_score": 8.5, "owasp": "LLM01"}
```

### 4.3.2 Các Loại Sự Kiện Được Hỗ Trợ
1. **`status`:** Trạng thái văn bản tổng quan (Khởi tạo kết nối, chuyển module, hoàn tất).
2. **`progress`:** Tiến độ định lượng, cung cấp cả chỉ số payload hiện tại trong module và tỉ lệ phần trăm tích lũy tổng thể (`overall_percent`).
3. **`finding`:** Chi tiết từng điểm phát hiện lỗ hổng ngay khi lớp phân tích hoàn tất, hiển thị trực tiếp lên bảng kết quả mà không cần đợi quét xong toàn bộ.
4. **`complete`:** Tín hiệu đóng phiên, cập nhật báo cáo tổng kết và mở khóa giao diện người dùng.
5. **`error`:** Thông báo lỗi kết nối socket hoặc timeout.

---

## 4.4 Tầng Lưu Trữ Dữ Liệu và Mô Hình Thực Thể Quan Hệ (Persistence Layer)

Toàn bộ dữ liệu kiểm thử được lưu trữ bền vững trong cơ sở dữ liệu quan hệ nhúng **SQLite (`scanner.db`)**, đảm bảo tính toàn vẹn ACID mà không đòi hỏi thiết lập máy chủ database phức tạp.

### 4.4.1 Lược Đồ Bảng `scans` (Phiên Quét)
Bảng `scans` quản lý thông tin vòng đời của từng phiên kiểm thử:
- `id` (INTEGER, Primary Key, Auto-increment): Định danh phiên quét.
- `target_url` (TEXT): Địa chỉ máy chủ AI mục tiêu (ví dụ: `http://localhost:11434`).
- `target_model` (TEXT): Tên mô hình AI được kiểm thử (ví dụ: `llama3`, `mistral`).
- `status` (TEXT): Trạng thái (`running`, `completed`, `cancelled`, `failed`).
- `total_findings` (INTEGER): Tổng số lượng lỗ hổng được ghi nhận.
- `critical_count`, `high_count`, `medium_count`, `low_count`: Thống kê số lượng theo cấp độ rủi ro.
- `started_at` (DATETIME): Thời điểm bắt đầu quét.
- `completed_at` (DATETIME): Thời điểm kết thúc phiên.

### 4.4.2 Lược Đồ Bảng `findings` (Bằng Chứng Lỗ Hổng)
Bảng `findings` lưu giữ chi tiết kỹ thuật của từng lỗ hổng phát hiện được:
- `id` (INTEGER, Primary Key): Định danh phát hiện.
- `scan_id` (INTEGER, Foreign Key referencing `scans.id`): Liên kết phiên quét.
- `module_name` (TEXT): Tên module thực hiện kiểm thử.
- `payload` (TEXT): Câu lệnh đối kháng gửi tới mô hình.
- `response` (TEXT): Phản hồi chi tiết nhận được từ mô hình AI.
- `severity` (TEXT): Mức độ rủi ro (`CRITICAL`, `HIGH`, `MEDIUM`, `LOW`, `INFO`).
- `risk_score` (REAL): Điểm số rủi ro chuẩn hóa CVSS ($0.0 - 10.0$).
- `owasp_code` (TEXT): Mã định danh OWASP Top 10 for LLM 2025 (`LLM01` - `LLM10`).
- `mitre_code` (TEXT): Mã kỹ thuật MITRE ATLAS (`AML.T00xx`).
- `timestamp` (DATETIME): Thời điểm ghi nhận.

Kiến trúc này cho phép người dùng truy vấn lịch sử quét, tái hiện kết quả thực nghiệm và xuất báo cáo kiểm toán bảo mật chuẩn hóa phục vụ hội đồng nghiệm thu đề tài.
